package cs520.module6.L1_threads;

public class MasterThread {
}
