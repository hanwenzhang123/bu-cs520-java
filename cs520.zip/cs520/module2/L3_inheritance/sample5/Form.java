package cs520.module2.L3_inheritance.sample5;

public abstract class Form {
    public abstract void form();
}