package cs520.module2.L3_inheritance.sample5;

interface Drawable {
    public void draw();
}