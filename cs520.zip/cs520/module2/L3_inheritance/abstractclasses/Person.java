package cs520.module2.L3_inheritance.abstractclasses;

public abstract class Person {

	public abstract void walk();

	public abstract void talk();
	
	public abstract void sleep();

	public abstract double computeExamScore();
}

