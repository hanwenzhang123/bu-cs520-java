package cs520.module2.L3_inheritance.sample2;

//Derive the Faculty class from the Person class

class Faculty extends Person {
}
