package cs520.module2.L3_inheritance.sample2;

// Derive the Student class from the Person class

public class Student extends Person {

    public Student() {
        age  = 30;
    }

    public String getName() {
        return "Mr. Student";
    }

}
