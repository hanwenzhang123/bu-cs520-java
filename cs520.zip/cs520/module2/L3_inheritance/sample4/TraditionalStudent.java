package cs520.module2.L3_inheritance.sample4;

public class TraditionalStudent extends Student {

	public TraditionalStudent() {
	}

	public TraditionalStudent(String theName, String theId) {
		super(theName, theId);
	}

	public TraditionalStudent(String theName, String theId, String theProgram) {
		super(theName, theId, theProgram);
	}

}
