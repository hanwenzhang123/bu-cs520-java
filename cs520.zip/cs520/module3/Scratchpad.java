package cs520.module3;

import java.util.Scanner;

public class Scratchpad {
    
    public static void main(String[] args) {
        try {
            Scanner s = new Scanner(System.in);
            String input = s.nextLine();
            int x = Integer.parseInt(input);
        } catch (Exception e) {
            
        }

    }
    
}