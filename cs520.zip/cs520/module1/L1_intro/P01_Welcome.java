package cs520.module1.L1_intro;

public class P01_Welcome {
	
	public static void main(String[] args) {

		// Display a greeting in the console window
		System.out.println("Welcome to Java!");
		System.out.println("Computers are great at arithmetic");

		int a = 11;
		int b = 22;
		int sum = a + b;
		System.out.println("The sum of " + a + " + " + b + " is " + sum);

	}

}
