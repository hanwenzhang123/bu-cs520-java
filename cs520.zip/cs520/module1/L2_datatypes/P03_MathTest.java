package cs520.module1.L2_datatypes;

public class P03_MathTest {

	public static void main(String[] args) {
		int x = 3;
		int y = 2;
		int myInt = x / y;
		double myDouble1 = x / y;
		double myDouble2 = (double)x / (double)y;
		System.out.println(myInt);
		System.out.println(myDouble1);
		System.out.println(myDouble2);
	}

}
